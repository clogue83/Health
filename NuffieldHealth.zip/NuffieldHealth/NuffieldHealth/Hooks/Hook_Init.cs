﻿using TechTalk.SpecFlow;
using System;
using NuffieldHealth.Drivers;
using OpenQA.Selenium;
using NuffieldHealth.Config;

namespace NuffieldHealth.Hooks
{
    [Binding]
    public sealed class Hook_Init
    {
        private readonly ScenarioContext _scenarioContext;
        public IWebDriver _browserSession;
        public Hook_Init(ScenarioContext scenarioContext)=> _scenarioContext = scenarioContext;


        [BeforeScenario]
        public void BeforeScenario()
        {
            SeleniumWebDriver driver = new SeleniumWebDriver(_scenarioContext);          
            _scenarioContext.Set(driver, "SeleniumWebDriver");
            _browserSession = driver.Setup();         
        }

        [AfterScenario]
        public void AfterScenario()
        {
            _browserSession = _scenarioContext.Get<IWebDriver>("WebDriver");
            _browserSession.Manage().Cookies.DeleteAllCookies();
            _browserSession.Close();
            _browserSession.Quit();
        }
    }
}