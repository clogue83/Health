﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace NuffieldHealth.Utils
{
    internal class Logger
    {
            public static void LogInteraction(string control, object currentValue, object newValue)
            {
                TestContext.Progress.WriteLine($"{DateTime.Now} : INTERACTION :- Setting \"{control}\" value from \"{currentValue}\" to \"{newValue}\"");
            }

            public static void LogState(string control, object currentValue)
            {
                TestContext.Progress.WriteLine($"{DateTime.Now} : STATE       :- Current value of \"{control}\" is \"{currentValue}\"");
            }

            public static void LogInfo(string message)
            {
                TestContext.Progress.WriteLine($"{DateTime.Now} : INFO        :- {message}");
            }

            public static void LogWarning(string message)
            {
                TestContext.Progress.WriteLine($"{DateTime.Now} : WARNING     :- {message}");

            }

            public static void LogError(string message)
            {
                TestContext.Progress.WriteLine($"{DateTime.Now} : ERROR       :- {message}");

            }

        }
    }


