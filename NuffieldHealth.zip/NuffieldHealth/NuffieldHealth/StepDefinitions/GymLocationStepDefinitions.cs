using System;
using NuffieldHealth.Drivers;
using NuffieldHealth.PageObjects;
using NuffieldHealth.PageObjects.Common;
using NuffieldHealth.PageObjects.Common.Common_Actions;
using OpenQA.Selenium;
using TechTalk.SpecFlow;
using FluentAssertions;

namespace NuffieldHealth.StepDefinitions
{
    [Binding]
    public class GymLocationStepDefinitions
    {
        private IWebDriver driver;
        private readonly ScenarioContext _scenarioContext;
        Common_Actions _actions;
        public GymLocationStepDefinitions(ScenarioContext scenarioContext)
        { 
            _scenarioContext = scenarioContext;
            driver = _scenarioContext.Get<IWebDriver>("WebDriver");
            _actions = new Common_Actions(driver);
        }

        

        #region Given Steps
        [Given(@"Bob wants to locate a (.*) in his area")]
        public void LocateAHealthSearvice(string healthService)
        {
            _actions.NavigateToHealthService(healthService);

        }

        [Given(@"Bob has located a (.*) in the (.*) area")]
        public void GivenBobHasLocatedAHealthSerivceInMyArea(string healthService, string area)
        {
           
        }
        #endregion

        #region When Steps
        [When(@"He searches by current location")]
        public void WhenHeSearchesByCurrentLocation()
        {
            _actions.SearchByCurrentLocation();    
        }

        
        [When(@"He searches the location (.*)")]
        public void WhenHeSearchesByLocation(string locationArea)
        {
            _actions.SearchHealthServiceByLocation(locationArea);
        }


        [When(@"He clicks a (.*)")]
        public void WhenHeClicksAHealthService(string healthService)
        {
        }
        #endregion

        #region Then Steps
        [Then(@"Only Gyms which offer a tour will be listed")]
        public void ThenOnlyGymsWhichOfferATourWillBeListed()
        {
            
        }

        [Then(@"The contact details are displayed")]
        public void ThenTheContactDetailsAreDisplayed()
        {
            
        }

        [Then(@"Only Gyms in (.*) will be listed")]
        public void ThenOnlyGymsInHisAreaWillBeListed(string location)
        {
           bool onlyLocalListed =_actions.AreLocationResultsCorrect(location);
           onlyLocalListed.Should().BeTrue();  
        }

        [Then(@"Virtual Gyms will also be listed")]
        public void ThenVirtualGymsWillAlsoBeListed()
        {
           
        }
        #endregion
    }
}
