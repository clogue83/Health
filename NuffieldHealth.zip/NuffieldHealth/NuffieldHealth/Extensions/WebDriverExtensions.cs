﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using NuffieldHealth.Utils;
using NuffieldHealth.Config;

namespace NuffieldHealth.Extensions
{
    public static class WebDriverExtensions
    {
        //Overrides default FindElement that accepts a time value in seconds to wait for, should some elements take longer to display than default setting
        public static OpenQA.Selenium.IWebElement FindElement(this IWebDriver driver, By by, TimeSpan timeoutInMilliSeconds)
        {
            try
            {
                var wait = new WebDriverWait(driver, timeoutInMilliSeconds);
                wait.PollingInterval = DriverConfig.PollingInterval;
                wait.Timeout = timeoutInMilliSeconds;   
                wait.IgnoreExceptionTypes(typeof(NoSuchElementException));
                
                var element = wait.Until<IWebElement>(driver =>
                {
                    try
                    {
                        var elementToFind = driver.FindElement(by);
                        if (elementToFind.Displayed && elementToFind.Enabled)
                        {
                            return elementToFind;
                        }
                        return null;
                    }
                    catch (StaleElementReferenceException)
                    {
                        return null;
                    }
                    catch (NoSuchElementException)
                    {
                        return null;
                    }
                });

                return element;
            }
            catch (Exception ex)
            {
                Logger.LogError("element vould not be found " + by.ToString());
                return null;

            }
        }

        public static void Click(this IWebElement element)
        {
            bool staleElement = true;
            while (staleElement)
            {
                try
                {
                    element.Click();
                    staleElement = false;
                    Logger.LogInfo(element.ToString() + " was clicked");
                }

                catch (StaleElementReferenceException)
                {

                    staleElement = true;
                    Logger.LogInfo(element.ToString() + " could not be clicked due to stale reference");
                }

            }
        }
    }
}