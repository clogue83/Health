﻿using NuffieldHealth.Config;
using NuffieldHealth.PageObjects.Common;
using NuffieldHealth.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.Extensions;
using System;
using System.Collections.Generic;
using System.Security.AccessControl;
using System.Text;
using TechTalk.SpecFlow;

namespace NuffieldHealth.Drivers
{
    public class SeleniumWebDriver
    {
        private IWebDriver driver;

        private readonly ScenarioContext _scenarioContext;

        public SeleniumWebDriver(ScenarioContext scenarioContext) => _scenarioContext = scenarioContext;

        public IWebDriver Setup()
        {
            try
            {

                //options for ChromeDriver
                var chromeDriverOptions = new ChromeOptions();

                driver = new RemoteWebDriver(DriverConfig.SeleniumServerUri, chromeDriverOptions.ToCapabilities());

                //watforBrowser to appear
                driver.Manage().Timeouts().PageLoad = DriverConfig.WaitForPageToDisplay;

                driver.Manage().Timeouts().ImplicitWait = DriverConfig.Timeout;

                driver.Navigate().GoToUrl(DriverConfig.NuffieldHealthURL);

                //driver.Manage().

                _scenarioContext.Set(driver, "WebDriver");

                driver.Manage().Window.Maximize();

                Common_Page _commonPage = new Common_Page(driver);
                _commonPage.AcceptCookies.Click();

                return driver;

            }

            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                return null;
            }


            
        }

        public IWebDriver getWebDriver()
        {
            IWebDriver driver = _scenarioContext.Get<IWebDriver>("WebDriver");
            return driver;
        }


        public void ResetBrowserSession()
        {
            IWebDriver browserSession = _scenarioContext.Get<IWebDriver>("WebDriver");
            Logger.LogInfo("Detaching browser session");
            browserSession.Manage().Cookies.DeleteAllCookies();
            browserSession.Navigate();
        }
    }
}
