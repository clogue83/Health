﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NuffieldHealth.Config
{    
    enum NavigationMenuItems
    {
        HOSPITALS,
        GYMS,
        SERVICES,
        ADVICEHUBS
    }
}
