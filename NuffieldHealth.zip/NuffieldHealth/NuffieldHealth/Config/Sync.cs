﻿using NuffieldHealth.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Timers;

namespace NuffieldHealth.Config
{
    public class Sync
    {

        IWebDriver sync_webdriver;
        public Sync(IWebDriver driver)
        {
            sync_webdriver = driver;
        }

        private DefaultWait<IWebDriver> SetupWait(IWebDriver driver, TimeSpan timeSpanInMilliSeconds )
        {
            //create the wait object using the driver and the timeout
            DefaultWait<IWebDriver> fluentWait = new DefaultWait<IWebDriver>(driver);

            fluentWait.Timeout = DriverConfig.Timeout;

            fluentWait.PollingInterval = DriverConfig.PollingInterval;

            return fluentWait;

        }

        public void WaitForTime(int SecondsToWait)
        {
            var timeout = DateTime.Now.AddSeconds(SecondsToWait);

            while (DateTime.Now < timeout)
            {
                Logger.LogInfo("Waiting for wait method to complete");
            }
            Logger.LogInfo("Wait complete");
        }


        public void WaitForPageLoadCompleted()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)sync_webdriver;
            DefaultWait<IWebDriver> wait = SetupWait(sync_webdriver, DriverConfig.WaitForPageToDisplay);
            wait.Until(wd => js.ExecuteScript("return document.readyState").ToString() == "complete");
            WaitForAjax();
    
        }

        public void WaitForAjax()
        {
            var wait = new WebDriverWait(sync_webdriver, DriverConfig.Timeout);
            wait.Until(d => (bool)(d as IJavaScriptExecutor).ExecuteScript("return jQuery.active == 0"));
        }
        
    }

}
