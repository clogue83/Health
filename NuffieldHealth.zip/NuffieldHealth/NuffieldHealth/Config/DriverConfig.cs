﻿using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Security.Policy;
using System.Text;

namespace NuffieldHealth.Config
{
    public static class DriverConfig
    {
        /// Default URI for WebDriver
        public static Uri SeleniumServerUri = new Uri("http://localhost:4444/");

        /// Default URL for WebPage
        public static string NuffieldHealthURL = "https://www.nuffieldhealth.com";

        /// Change this value to determine how long the session should wait to ensure the form is displayed before binding
        public static TimeSpan WaitForPageToDisplay = TimeSpan.FromMilliseconds(20000);

        /// Change this value to determine how frequently in milliseconds to retry seraching for element
        public static TimeSpan PollingInterval = TimeSpan.FromMilliseconds(300);

        /// Time to wait in seconds to find the element
        public static TimeSpan WaitForElementTimeout = TimeSpan.FromMilliseconds(5000);

        /// Change this value to determine how long the session should wait to ensure a selected control is displayed before interacting
        public static TimeSpan Timeout = TimeSpan.FromMilliseconds(8000);
    }


}
