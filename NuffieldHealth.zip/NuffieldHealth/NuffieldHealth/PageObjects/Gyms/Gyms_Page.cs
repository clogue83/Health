﻿using OpenQA.Selenium;
using NuffieldHealth.Extensions;
using NuffieldHealth.Config;
using System;
using System.Collections.Generic;
using System.Text;

namespace NuffieldHealth.PageObjects.Common
{
    public class Gyms_Page
    {
        private IWebDriver gym_Webdriver;
        public Gyms_Page(IWebDriver _webdriver)
        {
            gym_Webdriver = _webdriver;
        }

        public IWebElement txtGymLocationFinder => gym_Webdriver.FindElement(By.CssSelector(".location-finder__form--visible [type]"), DriverConfig.WaitForElementTimeout);

    }
}
