﻿using FluentAssertions;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using NuffieldHealth.Config;
using NuffieldHealth.Extensions;
using NuffieldHealth.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;

namespace NuffieldHealth.PageObjects.Common.Common_Actions
{
    internal class Common_Actions : Common_Page
    {
        Sync _sync;
        IWebDriver commActions_Webdriver;
        public Common_Actions(IWebDriver _webdriver) : base(_webdriver)
        {
            commActions_Webdriver = _webdriver;
            _sync = new Sync(commActions_Webdriver);
        }

        public void NavigateTo(NavigationMenuItems menuItem)
        {
            Sync _sync = new Sync(commActions_Webdriver);

            switch (menuItem)
            {
                case NavigationMenuItems.HOSPITALS:

                    HospitalsMenuItem.Click();                   
                    break;

                case NavigationMenuItems.GYMS:

                    GymsMenuItem.Click();
                    break;

                case NavigationMenuItems.SERVICES:

                    ServicesMenuItem.Click();
                    break;

                case NavigationMenuItems.ADVICEHUBS:
                    AdviceHubsMenuItem.Click();
                    break;
            }           
        }

        public void NavigateToHealthService(String HealthService)
        {
            try
            {
                if (HealthService == "Gym")
                {
                    NavigateTo(NavigationMenuItems.GYMS);
                    JoinAGymButton.Click();
                    _sync.WaitForPageLoadCompleted();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to navigate via Navigation menu");
                Logger.LogError(ex.Message);
            }
            
        }

        public void SearchHealthServiceByLocation(string locationArea)
        {
            try
            {
                _sync.WaitForTime(3);
                LocationSearchField.Click();
                LocationSearchField.SendKeys("Glasgow");
                LocationSearchField.Submit();
                _sync.WaitForTime(3);
                LocationSearchField.SendKeys(Keys.Down);
                LocationSearchField.SendKeys(Keys.Return);
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to search by location");
                Logger.LogError(ex.Message);
            }
            
        }

        public void SearchByCurrentLocation()
        {
            try 
            {
                LocationCurrent.Click();                
            }

            catch(Exception ex)
            {
                Logger.LogError(ex.Message);
            }          
        }

        public bool AreLocationResultsCorrect(string locationArea)
        {
            try
            {
                var locationItems = locationListGrid.FindElements(By.CssSelector("li"));
                int locationItemIndex = 0;

                bool correctArea = false;

                foreach (IWebElement locationItem in locationItems)
                {
                    if (!locationItem.Text.Contains("Virtual"))
                    {
                        locationItemIndex++;

                        if (locationItem.Text.Contains(locationArea))
                        {
                            correctArea = true;
                        }
                        else
                        {
                            correctArea = false;
                            break;
                        }
                    }
                }

                return correctArea;
            }
            catch (Exception ex)
            {
                Logger.LogError(ex.Message);
                return false;
            }        
        }
    }
}
