﻿using NuffieldHealth.Config;
using NuffieldHealth.Extensions;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace NuffieldHealth.PageObjects.Common
{
    
    public partial class Common_Page
    {
        private IWebDriver comm_Webdriver;

        public Common_Page(IWebDriver _webdriver)
        { 
            comm_Webdriver = _webdriver;
        }

        #region Cookie Setttings

        public IWebElement AcceptCookies => comm_Webdriver.FindElement(By.Id("ccc-notify-accept"), DriverConfig.WaitForElementTimeout);
        #endregion

        #region Common Menu and Header Items
        public IWebElement NuffieldHealthLogo => comm_Webdriver.FindElement(By.CssSelector(".nav__logo > img[alt='Nuffield Health']"),DriverConfig.WaitForElementTimeout);
        public IWebElement HospitalsMenuItem => comm_Webdriver.FindElement(By.LinkText("HOSPITALS"),DriverConfig.WaitForElementTimeout);
        public IWebElement GymsMenuItem => comm_Webdriver.FindElement(By.LinkText("GYMS"),DriverConfig.WaitForElementTimeout);
        public IWebElement ServicesMenuItem => comm_Webdriver.FindElement(By.CssSelector("SERVICES"), DriverConfig.WaitForElementTimeout);
        public IWebElement AdviceHubsMenuItem => comm_Webdriver.FindElement(By.CssSelector("ADVICE HUBS"),DriverConfig.WaitForElementTimeout);
        public IWebElement NavigationPanel => comm_Webdriver.FindElement(By.CssSelector("div#nav > .nav__drawer"), DriverConfig.WaitForElementTimeout);
        #endregion

        #region Location Fields
        public IWebElement LocationSearchField => comm_Webdriver.FindElement(By.CssSelector(".location-finder__form--visible [type]"), DriverConfig.WaitForElementTimeout);

        public IWebElement LocationListView => comm_Webdriver.FindElement(By.CssSelector(".js-location-toggle-container [role] [role='tab']:nth-of-type(1)"), DriverConfig.WaitForElementTimeout);

        public IWebElement LocationList => comm_Webdriver.FindElement(By.CssSelector(".grid.grid--3.grid--gutter-narrow.js-location-finder-grid"), DriverConfig.WaitForElementTimeout);

        public IWebElement LocationViewMore => comm_Webdriver.FindElement(By.CssSelector(".location-finder__more--visible span"), DriverConfig.WaitForElementTimeout);
        #endregion
        public IWebElement LocationCurrent => comm_Webdriver.FindElement(By.LinkText("Or use my current location"), DriverConfig.WaitForElementTimeout);

        public IWebElement locationListGrid => comm_Webdriver.FindElement(By.CssSelector(".grid.grid--3.grid--gutter-narrow.js-location-finder-grid"), DriverConfig.WaitForElementTimeout);


    }
}
