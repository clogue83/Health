﻿using OpenQA.Selenium;
using NuffieldHealth.Extensions;
using System;
using System.Collections.Generic;
using System.Text;
using NuffieldHealth.Config;

namespace NuffieldHealth.PageObjects.Common
{
    public partial class Common_Page
    {
        public IWebElement JoinAGymButton => comm_Webdriver.FindElement(By.LinkText("JOIN A GYM"), DriverConfig.Timeout);
    }
}
